const Joi = require('joi');

const rangeSchema = (min, max) =>
  Joi.object({
    min: Joi.number().min(min).max(max).optional(),
    max: Joi.number()
      .min(min)
      .max(max)
      .optional()
      .when('min', {
        is: Joi.exist(),
        then: Joi.number().min(Joi.ref('min'))
      })
  });

const updatePreferenceSchema = Joi.object({
  ageRange: rangeSchema(18, 100).optional(),
  heightRange: rangeSchema(100, 250).optional(),
  incomeRange: Joi.object({
    min: Joi.number().min(0).optional(),
    max: Joi.number().min(0).optional().when('min', {
      is: Joi.exist(),
      then: Joi.number().min(Joi.ref('min'))
    })
  }).optional(),

  religion: Joi.array().items(Joi.string().max(50)).optional(),
  caste: Joi.array().items(Joi.string().max(50)).optional(),
  education: Joi.array().items(Joi.string().max(100)).optional(),
  location: Joi.array().items(Joi.string().max(100)).optional(),

  maritalStatus: Joi.array()
    .items(Joi.string().valid('never_married', 'divorced', 'widowed', 'awaiting_divorce'))
    .optional()
});

module.exports = { updatePreferenceSchema };