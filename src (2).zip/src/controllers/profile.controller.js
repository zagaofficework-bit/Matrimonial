const asyncHandler = require('../utils/asyncHandler');
const { sendSuccess } = require('../utils/ApiResponse');
const profileService = require('../services/profile.service');

const getMyProfile = asyncHandler(async (req, res) => {
  const profile = await profileService.getMyProfile(req.user._id);
  return sendSuccess(res, 200, 'Profile mil gayi.', { profile });
});

const updateMyProfile = asyncHandler(async (req, res) => {
  const profile = await profileService.upsertMyProfile(req.user._id, req.body);
  return sendSuccess(res, 200, 'Profile update ho gayi.', { profile });
});

// GET /api/profile/browse - Home page ka profile grid
const browseProfiles = asyncHandler(async (req, res) => {
  const currentUserId = req.user ? req.user._id : null;
  const currentUserGender = req.user ? req.user.gender : null;
  const profiles = await profileService.browseProfiles(currentUserId, currentUserGender);
  return sendSuccess(res, 200, 'Profiles mil gayi.', { profiles });
});

// GET /api/profile/:id - kisi bhi member ki public profile
const getProfileById = asyncHandler(async (req, res) => {
  const profile = await profileService.getProfileById(req.params.id);
  return sendSuccess(res, 200, 'Profile mil gayi.', { profile });
});

module.exports = { getMyProfile, updateMyProfile, browseProfiles, getProfileById };