import { useNavigate } from 'react-router-dom';
import './ProfileCard.css';

function calculateAge(dob) {
  if (!dob) return null;
  const diff = Date.now() - new Date(dob).getTime();
  return Math.floor(diff / (1000 * 60 * 60 * 24 * 365.25));
}

export default function ProfileCard({ profile }) {
  const navigate = useNavigate();

  const primaryPhoto =
    profile.photos?.find((p) => p.isPrimary)?.url || profile.photos?.[0]?.url || null;

  const age = calculateAge(profile.user?.dob);
  const name = profile.user?.name || 'Unnamed';

  function goToProfile() {
    navigate(`/profile/${profile._id}`);
  }

  return (
    <div className="profile-card">
      <div className="profile-card-image" onClick={goToProfile}>
        {primaryPhoto ? (
          <img src={primaryPhoto} alt={name} />
        ) : (
          <div className="profile-card-placeholder">{name.charAt(0).toUpperCase()}</div>
        )}

        <div className="profile-card-overlay">
          <h3 className="profile-card-name">
            {name}
            {age ? `, ${age}` : ''}
          </h3>
          <svg className="profile-card-verified" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2l2.6 1.4 2.9-.3 1.2 2.6 2.6 1.4-.6 2.9.6 2.9-2.6 1.4-1.2 2.6-2.9-.3L12 22l-2.6-1.4-2.9.3-1.2-2.6L2.7 16.9l.6-2.9-.6-2.9 2.6-1.4 1.2-2.6 2.9.3z" />
            <path d="M9 12.3l2 2 4-4.2" stroke="#fff" strokeWidth="1.6" fill="none" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>

      <div className="profile-card-body">
        {profile.occupation && (
          <p className="profile-card-meta">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="7" width="18" height="13" rx="2" />
              <path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
            </svg>
            {profile.occupation}
          </p>
        )}
        <p className="profile-card-meta">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="12" cy="12" r="10" />
            <path d="M12 6v6l4 2" />
          </svg>
          {[profile.height ? `${profile.height} cm` : null, profile.religion].filter(Boolean).join(' • ') ||
            'Details coming soon'}
        </p>
        {profile.city && (
          <p className="profile-card-meta">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M21 10c0 6-9 12-9 12s-9-6-9-12a9 9 0 0 1 18 0z" />
              <circle cx="12" cy="10" r="3" />
            </svg>
            {profile.city}
          </p>
        )}

        <div className="profile-card-actions">
          <button type="button" className="btn btn-primary btn-sm" onClick={goToProfile}>
            <svg viewBox="0 0 24 24" fill="currentColor" width="14" height="14">
              <path d="M12 21s-7.2-4.5-10-9.3C.4 8.3 2 4.6 5.6 4a5 5 0 0 1 6.4 2A5 5 0 0 1 18.4 4c3.6.6 5.2 4.3 3.6 7.7C19.2 16.5 12 21 12 21z" />
            </svg>
            Connect
          </button>
          <button type="button" className="profile-card-save" aria-label="Save profile">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M11.5 3l2.2 4.6 5 .7-3.6 3.6.9 5-4.5-2.4-4.5 2.4.9-5-3.6-3.6 5-.7z" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
}
