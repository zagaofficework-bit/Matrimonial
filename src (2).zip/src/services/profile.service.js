const Profile = require('../models/Profile');
const User = require('../models/User');
const ApiError = require('../utils/ApiError');

// GET - apni profile dekhna
async function getMyProfile(userId) {
  const profile = await Profile.findOne({ user: userId }).populate('user', 'name gender dob phone email status');
  if (!profile) {
    throw new ApiError(404, 'Profile abhi tak bani nahi hai.', 'PROFILE_NOT_FOUND');
  }
  return profile;
}

// CREATE ya UPDATE - dono ek hi function se
async function upsertMyProfile(userId, payload) {
  const profile = await Profile.findOneAndUpdate(
    { user: userId },
    { $set: payload, user: userId },
    { new: true, upsert: true, runValidators: true, setDefaultsOnInsert: true }
  );
  return profile;
}

// Home page ka "Browse Profiles" grid - saari active profiles list karta hai,
// khud ko aur suspended/deleted users ko exclude karke. Agar logged-in user
// ka gender pata hai to opposite gender automatically dikhata hai (jaise search me).
async function browseProfiles(currentUserId, currentUserGender) {
  const userQuery = { status: { $nin: ['suspended', 'deleted'] } };

  if (currentUserId) userQuery._id = { $ne: currentUserId };
  if (currentUserGender) {
    userQuery.gender = currentUserGender === 'male' ? 'female' : 'male';
  }

  const matchingUsers = await User.find(userQuery).select('_id');
  const userIds = matchingUsers.map((u) => u._id);

  const profiles = await Profile.find({ user: { $in: userIds } })
    .populate('user', 'name gender dob phone email status')
    .sort({ createdAt: -1 });

  return profiles;
}

// Public profile page - Profile ki apni _id se dhundhta hai
// (ProfileCard navigate karte waqt profile._id use karta hai, user._id nahi).
async function getProfileById(profileId) {
  const profile = await Profile.findById(profileId).populate('user', 'name gender dob phone email status');
  if (!profile) {
    throw new ApiError(404, 'Profile nahi mili.', 'PROFILE_NOT_FOUND');
  }
  return profile;
}

module.exports = { getMyProfile, upsertMyProfile, browseProfiles, getProfileById };